A-Z Contractors LLC — Publish Ready Website

HOW TO PREVIEW
1. Open index.html in a browser.

HOW TO PUBLISH FREE WITH CLOUDFLARE PAGES
1. Create a GitHub account if you do not have one.
2. Create a new repository called az-contractors-website.
3. Upload index.html and the assets folder from this package.
4. In Cloudflare, open Workers & Pages > Create > Pages > Connect to Git.
5. Connect your GitHub repository.
6. Framework preset: None.
7. Build command: leave blank.
8. Build output directory: /
9. Deploy.
10. In Cloudflare Pages > Custom domains, add your .com domain.

IMPORTANT BEFORE FINAL LAUNCH
- Replace the sample/recreated project images with your real project photos.
- Confirm your business email is azcontractorsllc@gmail.com.
- Add your exact WA contractor license number if you want it visible.
- Add verified Google reviews instead of placeholder review text.

Phone already configured: (425) 528-3360
